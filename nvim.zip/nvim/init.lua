-- Load .vim first
local vimrc = vim.fn.stdpath("config") .. "/start.vim"
vim.cmd.source(vimrc)

require('user.lsp')
